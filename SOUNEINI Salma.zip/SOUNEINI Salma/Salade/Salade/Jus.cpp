#include "Jus.h"

Jus::Jus(Fruit** tabfruit):jus(tabfruit)
{
}

Jus::~Jus()
{
}
