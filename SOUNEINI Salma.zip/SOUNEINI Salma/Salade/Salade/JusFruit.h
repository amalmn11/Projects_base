#pragma once


class JusFruit
{
public:
	 virtual void afficher() const = 0;
};

