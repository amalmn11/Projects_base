#include "fruit.h"

void Fruit::afficher() const
{
}
