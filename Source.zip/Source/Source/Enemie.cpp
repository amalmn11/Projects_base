#include "Enemie.h"
#include <iostream>
#include <cmath> // Pour std::floor

// Constructeur
Enemie::Enemie(const std::string& textureFile, float initSpeed)
    : direction(0), movementTimer(0) {
    if (!texture.loadFromFile(textureFile)) {
        std::cerr << "Erreur de chargement de la texture de l'ennemi!" << std::endl;
    }
    sprite.setTexture(texture);
    speed = initSpeed;
}

// M�thode pour positionner l'ennemi
void Enemie::setPosition(float x, float y) {
    sprite.setPosition(x, y);
}

// M�thode pour obtenir la position de l'ennemi
sf::Vector2f Enemie::getPosition() const {
    return sprite.getPosition();
}

// M�thode pour d�placer l'ennemi
void Enemie::move(float deltaTime, const Maze& maze) {
    // Conversion de la position de l'ennemi en coordonn�es de grille
    sf::Vector2f position = sprite.getPosition();
    int gridX = static_cast<int>(std::floor(position.x / Maze::TILE_SIZE));
    int gridY = static_cast<int>(std::floor(position.y / Maze::TILE_SIZE));

    // Incr�mente le timer
    movementTimer += deltaTime;

    // Se d�placer uniquement apr�s un certain intervalle
    if (movementTimer >= 0.5f) { // 0.5s entre les mouvements
        movementTimer = 0; // R�initialiser le timer

        // Calcul de la nouvelle position en fonction de la direction actuelle
        int newGridX = gridX, newGridY = gridY;
        switch (direction) {
        case 0: // Gauche
            newGridX -= 1;
            break;
        case 1: // Droite
            newGridX += 1;
            break;
        case 2: // Haut
            newGridY += 1;
            break;
        case 3: // Haut
            newGridY -= 1;
            break;
        }

        // V�rification si le d�placement est valide
        if (maze.isPath(newGridX, newGridY)) {
            // Appliquer le mouvement
            sprite.setPosition(newGridX * Maze::TILE_SIZE, newGridY * Maze::TILE_SIZE);
        }

        // Passer � la direction suivante (0 -> 1 -> 2 -> 0)
        direction = (direction + 1) % 3;
    }
}




// M�thode pour dessiner l'ennemi
void Enemie::draw(sf::RenderWindow& window) {
    window.draw(sprite);
}

// M�thode pour v�rifier la collision avec Pac-Man
bool Enemie::checkCollision(const sf::Sprite& pacManSprite) const {
    return sprite.getGlobalBounds().intersects(pacManSprite.getGlobalBounds());
}

// M�thode pour v�rifier si l'ennemi peut se d�placer dans une direction donn�e
bool Enemie::canMove(int gridX, int gridY, const std::vector<std::vector<int>>& grid) {
    return gridY >= 0 && gridY < static_cast<int>(grid.size()) &&
        gridX >= 0 && gridX < static_cast<int>(grid[0].size()) &&
        grid[gridY][gridX] == 0;
}

// M�thode pour tuer l'ennemi (r�initialisation de sa position)
void Enemie::die() {
    sprite.setPosition(-100, -100); // D�place l'ennemi en dehors de l'�cran
}
