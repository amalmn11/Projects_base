#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include "Maze.h" // N�cessaire pour utiliser Maze

class Enemie {
private:
    sf::Sprite sprite;   // L'image de l'ennemi
    sf::Texture texture; // La texture de l'ennemi
    float speed;         // Vitesse de d�placement de l'ennemi
    int direction;       // Direction actuelle (0: gauche, 1: droite, 2: haut)
    float movementTimer; // Timer pour contr�ler le rythme du mouvement

public:
    // Constructeur
    Enemie(const std::string& textureFile, float initSpeed);

    // M�thode pour positionner l'ennemi
    void setPosition(float x, float y);

    // M�thode pour obtenir la position de l'ennemi
    sf::Vector2f getPosition() const;

    // M�thode pour d�placer l'ennemi
    void move(float deltaTime, const Maze& maze);

    // M�thode pour dessiner l'ennemi
    void draw(sf::RenderWindow& window);

    // M�thode pour v�rifier la collision avec Pac-Man
    bool checkCollision(const sf::Sprite& pacManSprite) const;

    // M�thode pour v�rifier si l'ennemi peut se d�placer dans une direction donn�e
    bool canMove(int gridX, int gridY, const std::vector<std::vector<int>>& grid);

    // M�thode pour tuer l'ennemi (r�initialisation de sa position)
    void die();
};
