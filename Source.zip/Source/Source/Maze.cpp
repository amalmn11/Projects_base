#include "Maze.h"

// Constructeur par d�faut avec une grille pr�d�finie
Maze::Maze()
    : grid({
          {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
          {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
          {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1},
          {1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1},
          {1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1},
          {1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1},
          {1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1},
          {1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1},
          {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1},
          {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
          {1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1},
          {1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1},
          {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1},
          {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        }),
    wallColor(sf::Color::Green), pathColor(sf::Color::Black)  // Murs rouges, chemins noirs

{}



// Constructeur avec grille personnalis�e
Maze::Maze(const std::vector<std::vector<int>>& customGrid)
    : grid(customGrid), wallColor(sf::Color::Green), pathColor(sf::Color::Black) {}



// Affichage console du labyrinthe
void Maze::display() const {
    for (const auto& row : grid) {
        for (int cell : row) {
            std::cout << (cell == 1 ? "#" : " ") << " ";
        }
        std::cout << std::endl;
    }
}



// Dessin dans la fen�tre SFML
void Maze::draw(sf::RenderWindow& window) const {
    for (int i = 0; i < static_cast<int>(grid.size()); ++i) {
        for (int j = 0; j < static_cast<int>(grid[i].size()); ++j) {
            sf::RectangleShape tile(sf::Vector2f(TILE_SIZE, TILE_SIZE));
            tile.setPosition(static_cast<float>(j * TILE_SIZE), static_cast<float>(i * TILE_SIZE));

            tile.setFillColor(grid[i][j] == 1 ? wallColor : pathColor);
            window.draw(tile);
        }
    }
}

bool Maze::isCollisionWithWall(const sf::Vector2f& position) const {
    int row = static_cast<int>(position.y) / TILE_SIZE;
    int col = static_cast<int>(position.x) / TILE_SIZE;

    // V�rifier si la position est en dehors des limites de la grille ou sur un mur
    if (row < 0 || row >= grid.size() || col < 0 || col >= grid[0].size()) {
        return true; // En dehors des limites
    }

    return grid[row][col] == 1;  // V�rifier si c'est un mur
}


// Retourne la couleur du carreau � la position donn�e (en pixels)
sf::Color Maze::getTileColor(int x, int y) const {
    int row = y / TILE_SIZE;
    int col = x / TILE_SIZE;

    if (row < 0 || row >= grid.size() || col < 0 || col >= grid[0].size()) {
        return sf::Color::Transparent; // Hors limites
    }

    // Si c'est un mur (1), la couleur est rouge (ou vert si vous avez modifi�)
    if (grid[row][col] == 1) {
        return wallColor;  // Mur
    }

    return pathColor;  // Chemin
}


bool Maze::isPath(int x, int y) const {
    // V�rifie si les coordonn�es sont valides
    if (x < 0 || x >= static_cast<int>(grid[0].size()) || y < 0 || y >= static_cast<int>(grid.size())) {
        return false; // Hors limites
    }
    return grid[y][x] == 0; // Retourne vrai si c'est un chemin noir
}



Maze::~Maze() {}
